bedroom_choices={
    '1':1,
    '2':2,
    '3':3,
    '4':4,
    
}


state_choices = {
                    "AK": "Alaska",
                    "AZ": "Arizona",
                    "AR": "Arkansas",
                    "CA" : "California"
}
                   
price_choices = {


                 "100000": "$100,000",
                  "200000" :"$200,000",
                 "300000": "$300,000",
                  "400000" : "$400,000"
}
